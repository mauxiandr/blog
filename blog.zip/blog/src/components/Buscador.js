import React, { Component } from 'react';

class Buscador extends Component {


	constructor() {
	    super();
	    this.state = {
	      search: ''
	    };
	    this.handleInput = this.handleInput.bind(this);
	    this.handleSubmit = this.handleSubmit.bind(this);
	    // this.isEmpty = this.isEmpty.bind(this);	    
	  }

	handleInput (e) {
		const { value, name } = e.target;
		this.setState({
			[name]: value
		});
	}

	handleSubmit (e) {
		e.preventDefault();
		this.props.onFilterPost(this.state);
		// document.getElementById("filterForm").reset();
	}

	render() {
		return (
			<div className="container">
            	<div className="col-md-12 mt-4">
					<form className="row" onSubmit={this.handleSubmit} id="filterForm">
						<div className="col-md-4 left">
							<div className="form-group">
								<input
									type="text"
									name="search"
									onChange={this.handleInput}
									// onKeyPress={this.isEmpty}
									className="form-control"
									placeholder="Filtrar por nombre"
								/>
							</div>
						</div>
						<div className="col-md-8 right">
							<button
								className="btn btn-primary right"
								type="submit"
							>
								Buscar
							</button>
						</div>
					</form>
				</div>
			</div>
		)
	}
}

export default Buscador;