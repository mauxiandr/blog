const conString = "postgres://postgres:m20a03r92@localhost/posts"

var pg = require('pg');

var client = new pg.Client(conString);

var notas_query = "SELECT * FROM posts";
var res;

  client.connect();

  client.query(notas_query, [], (err, result) => {
    res.json(result.rows);
    res.end();
    client.end()
  })