const obj = [
	{"nombre":'María Andrade', "edad":26, "estatura":'1.50cm'}
]

const cloneObj = []

for (i = 0; i < obj.length; i++){
	cloneObj.push(obj[i])
}

obj[0].nombre = "diego"

console.log(obj, cloneObj)