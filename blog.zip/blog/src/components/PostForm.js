import React, { Component } from 'react';

class PostForm extends Component {

	constructor() {
	    super();
	    this.state = {
	      title: '',
	      description: ''
	    };
	    this.handleInput = this.handleInput.bind(this);
	    this.handleSubmit = this.handleSubmit.bind(this);
	  }

	handleInput (e) {
		const { value, name } = e.target;
		this.setState({
			[name]: value
		});
	}

	handleSubmit (e) {
		e.preventDefault();
		this.props.onAddPost(this.state);
		document.getElementById("addForm").reset();
	}

	render() {
		return (
			<div className="container">
            	<div className="col-md-12 mt-4">
				<form className="row" onSubmit={this.handleSubmit} id="addForm">
					<div className="col-md-4 left">
						<div className="form-group">
							<input
								type="text"
								name="title"
								onChange={this.handleInput}
								className="form-control"
								placeholder="Título"
							/>
						</div>
					</div>
					<div className="col-md-6">
						<div className="form-group">
							<textarea
								type="text"
								name="description"
								onChange={this.handleInput}
								className="form-control"
								placeholder="Descripción"
							/>
						</div>
					</div>
					<div className="col-md-2 right">
						<button
							className="btn btn-primary right"
							type="submit"
						>
							Guardar
						</button>
					</div>
				</form>
				</div>
          	</div>
		)
	}
}

export default PostForm;
