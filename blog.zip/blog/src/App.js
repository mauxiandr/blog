import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import { posts } from "./posts.json";

import Navigation from "./components/Navigation";
import PostForm from "./components/PostForm";
import Buscador from "./components/Buscador";


class App extends Component {

  constructor() {
    super();
    this.state = {
      posts: [],
      filter: {
        title: '',
        search: ''
      }
    }
      this.handleAddPost = this.handleAddPost.bind(this);
      this.handleFilterPost = this.handleFilterPost.bind(this);
  }
  
  componentDidMount() {
    this.getPosts();
  }

  getPosts = _ => {
    fetch('http://localhost:4000/posts')
      .then(response => response.json())
      .then((response) => {
        this.setState({posts: response})
    })
    .catch(err => console.log(err))
  }

  handleAddPost(post) {
    this.setState({
      posts: [...this.state.posts, post]
    })
    fetch('http://localhost:4000/post/add', {
       method: 'post',
       body: {
        "title": post.title,
        "descrption": post.description 
      }
       } )
      .then(this.getPosts)
      .catch(err => console.error(err))
  }

  removePost(index) {
    if (window.confirm('¿Está seguro de querer eliminar el post?')) {
      // console.log(this.state.post)
      fetch(`http://localhost:4000/post/delete/${this.state.posts[index].id}`, {
        method: 'delete'
      } )
      .then(this.getPosts)
      .catch(err => console.error(err))
      this.setState({
        posts: this.state.posts.filter((elements, i) => {
          return i !== index
        })
      })
    }
  }
// ?id=' + this.state.posts[index].id 
  handleFilterPost(filter) {
    this.setState({
      posts: this.state.posts.filter((element, i) => 
        typeof element.title.toUpperCase() == "string" && element.title.toUpperCase().indexOf(filter.search.toUpperCase()) > -1 )
    })
  }

  render() {

    const posts = this.state.posts.map((post, i) => {
      return (
       
        <div className="col-md-4">
          <div className="card mt-4">
            <div className="card-header">
              <h3>{ post.title }</h3>
            </div>
            <div className="card-body">
              { post.description }
            </div>
            <div className="card-footer">
              <button
                className="btn btn-danger"
                onClick={this.removePost.bind(this, i)}
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
        
      )
    })

    return (
      <div className="App">

        <Navigation lengthPost={this.state.posts.length}/>

          <Buscador onFilterPost={this.handleFilterPost} onResetPosts={this.resetPosts}/>

          <div className="container">
            <div className="row mt-4">
              { posts }
            </div>
          </div>

          
          <PostForm onAddPost={this.handleAddPost}/>
          
      </div>
    );
  }
}

export default App;
